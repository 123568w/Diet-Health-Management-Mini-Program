App({
  onLaunch() {
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力');
    } else {
      wx.cloud.init({
        env: 'db-cloud-0gebkyxq512a8288', // 替换为你的云环境ID
        traceUser: true,        // 跟踪用户访问
      });
    }
  }
});