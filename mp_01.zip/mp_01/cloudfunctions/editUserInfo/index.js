const cloud = require('wx-server-sdk');

// 初始化云环境
cloud.init();
const db = cloud.database(); // 初始化数据库

// 云函数入口函数
exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext(); // 获取用户唯一标识
  const { name, age, height, weight } = event; // 从前端传来的数据

  // 参数校验
  if (!name || typeof name !== 'string') {
    return { success: false, message: '名称格式不正确' };
  }
  if (!age || typeof age !== 'number' || age <= 0) {
    return { success: false, message: '年龄必须为正整数' };
  }
  if (!height || typeof height !== 'number' || height <= 0) {
    return { success: false, message: '身高必须为正数' };
  }
  if (!weight || typeof weight !== 'number' || weight <= 0) {
    return { success: false, message: '体重必须为正数' };
  }

  try {
    // 检查文档是否存在
    const userDoc = await db.collection('users').doc(OPENID).get();
    if (userDoc.data) {
      // 如果文档存在，则更新数据
      await db.collection('users').doc(OPENID).update({
        data: {
          name, // 替换为数据库字段名
          age,
          height,
          weight,
        },
      });
    }
  } catch (err) {
    if (err.errCode === 'DATABASE_DOCUMENT_NOT_FOUND') {
      // 如果文档不存在，则创建新文档
      await db.collection('users').doc(OPENID).set({
        data: {
          name, // 替换为数据库字段名
          age,
          height,
          weight,
        },
      });
    } else {
      console.error('更新失败：', err);
      return {
        success: false,
        message: '更新失败，请稍后重试',
        error: err.message,
      };
    }
  }

  return {
    success: true,
    message: '更新成功',
  };
};
