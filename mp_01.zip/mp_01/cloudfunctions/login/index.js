// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

// 云函数入口函数
exports.main = async (event, context) => {
  const { account, password } = event;

  try {
    // 查询数据库中的用户信息
    const res = await db.collection('users').where({ account, password }).get();

    if (res.data.length > 0) {
      // 如果查询到用户，返回用户数据
      return { 
        success: true, 
        message: '登录成功', 
        data: res.data[0] 
      };
    } else {
      // 没有找到对应用户时
      return { 
        success: false, 
        message: '账号或密码错误', 
        data: {} 
      };
    }
  } catch (err) {
    console.error('数据库查询失败:', err);
    // 系统错误处理
    return { 
      success: false, 
      message: '系统错误，请稍后再试', 
      data: {} 
    };
  }
};