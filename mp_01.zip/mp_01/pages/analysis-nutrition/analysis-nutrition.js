Page({
  data: {
    totalProtein: 0,
    totalFat: 0,
    totalCarbs: 0,
    totalCalories: 0,
    healthScore: 0.00,  // 初始化为两位小数
    bmi: 0,
    calorieAdvice: '',
    nutritionAdvice: '',
    userInfo: {
      height: 175,  // 示例身高（厘米）
      weight: 70,   // 示例体重（公斤）
      age: 25,      // 示例年龄
      gender: 'male' // 示例性别
    }  // 包含用户的身高、体重、性别和年龄
  },

  onLoad: function (options) {
    const cart = wx.getStorageSync('cart') || [];
    let totalCalories = 0;
    let totalProtein = 0;
    let totalFat = 0;
    let totalCarbs = 0;

    // 计算总卡路里、蛋白质、脂肪、碳水化合物
    cart.forEach(item => {
      totalCalories += item.calories * item.quantity;
      totalProtein += item.protein * item.quantity;
      totalFat += item.fat * item.quantity;
      totalCarbs += item.carbs * item.quantity;
    });

    // 使用存储的用户信息或回退到示例值
    const userInfo = wx.getStorageSync('userInfo') || this.data.userInfo; // 如果存在则使用提供的用户信息
    const bmi = this.calculateBMI(userInfo.weight, userInfo.height);
    const advice = this.generateCalorieAdvice(bmi, totalCalories, userInfo);
    const healthScore = this.calculateHealthScore(totalProtein, totalFat, totalCarbs); // 计算健康得分

    let healthColor ;
    if (healthScore <= 30) {
      healthColor = 'red';
    } else if(healthScore > 30 && healthScore <= 60) {
      healthColor = 'orange';
    }else{
      healthColor = 'green';
    }

    this.setData({
      totalCalories: totalCalories.toFixed(2),
      totalProtein: totalProtein.toFixed(2),
      totalFat: totalFat.toFixed(2),
      totalCarbs: totalCarbs.toFixed(2),
      healthScore: healthScore.toFixed(2),  // 保留两位小数
      bmi: bmi.toFixed(2),
      calorieAdvice: advice,
      nutritionAdvice: this.generateNutritionAdvice(totalProtein, totalFat, totalCarbs), // 生成营养建议
      healthColor: healthColor  // 新增的数据属性，用于控制颜色
    });
  },

  // BMI 计算
  calculateBMI: function (weight, height) {
    if (height > 0) {  // 检查身高是否有效
      return weight / ((height / 100) ** 2);
    } else {
      return 0; // 如果身高无效，返回0
    }
  },

  // 生成卡路里建议
  generateCalorieAdvice: function (bmi, totalCalories, userInfo) {
    let bmr;

    // 根据性别计算基础代谢率（BMR）
    if (userInfo.gender === 'male') {
      bmr = 88.36 + (13.4 * userInfo.weight) + (4.8 * userInfo.height) - (5.7 * userInfo.age);
    } else {
      bmr = 447.6 + (9.2 * userInfo.weight) + (3.1 * userInfo.height) - (4.3 * userInfo.age);
    }

    const tdee = bmr * 1.55;

    if (bmi < 18.5) {
      return `您的BMI值为${bmi.toFixed(2)}，偏瘦。建议每天摄入至少${(tdee + 500).toFixed(0)} kcal以增重。`;
    } else if (bmi < 24.9) {
      return `您的BMI值为${bmi.toFixed(2)}，正常范围。建议保持每日摄入${tdee.toFixed(0)} kcal。`;
    } else {
      return `您的BMI值为${bmi.toFixed(2)}，偏重。建议每日卡路里控制在${(tdee - 500).toFixed(0)} kcal以下以减重。`;
    }
  },

  calculateHealthScore: function (totalProtein, totalFat, totalCarbs) {
    const totalNutrients = totalProtein + totalFat + totalCarbs;
 
    if (totalNutrients > 0) {
      // 计算每种营养素的实际占比
      const proteinPercentage = (totalProtein / totalNutrients) * 100;
      const fatPercentage = (totalFat / totalNutrients) * 100;
      const carbsPercentage = (totalCarbs / totalNutrients) * 100;
 
      // 推荐的宏量营养素分布范围（AMDR）
      const recommendedProteinRange = [10, 35]; // 蛋白质占比 10%-35%
      const recommendedFatRange = [20, 35];    // 脂肪占比 20%-35%
      const recommendedCarbsRange = [45, 65];  // 碳水化合物占比 45%-65%
 
      // 计算每种营养素的得分（偏离推荐范围越少，得分越高）
      const proteinScore = this.calculateNutrientScore(proteinPercentage, recommendedProteinRange);
      const fatScore = this.calculateNutrientScore(fatPercentage, recommendedFatRange);
      const carbsScore = this.calculateNutrientScore(carbsPercentage, recommendedCarbsRange);
 
      // 综合得分，赋予蛋白质、脂肪、碳水化合物不同权重
      const healthScore = (proteinScore * 0.4) + (fatScore * 0.3) + (carbsScore * 0.3);
      return healthScore; // 返回综合健康指数
    }
    return 0;  // 如果没有营养成分，返回0
  },
 
  // 辅助函数：根据实际占比与推荐范围的偏离计算得分
  calculateNutrientScore: function (actualPercentage, recommendedRange) {
    const [min, max] = recommendedRange;
 
    if (actualPercentage >= min && actualPercentage <= max) {
      return 100; // 完全在推荐范围内，得满分
    } else if (actualPercentage < min) {
      // 偏低，根据偏离程度扣分
      return Math.max(0, 100 - ((min - actualPercentage) * 5));
    } else {
      // 偏高，根据偏离程度扣分
      return Math.max(0, 100 - ((actualPercentage - max) * 5));
    }
  },

  // 生成营养建议
  generateNutritionAdvice: function (totalProtein, totalFat, totalCarbs) {
    if (totalFat > 60) {
      return "建议减少脂肪摄入，增加蛋白质与碳水化合物的比例。";
    } else if (totalProtein < 50) {
      return "建议增加蛋白质摄入，以满足身体需要。";
    } else {
      return "您的营养成分比例较为均衡，继续保持良好饮食习惯。";
    }
  },

  

  goBack: function () {
    wx.navigateBack();
  }
});
