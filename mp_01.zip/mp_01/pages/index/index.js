Page({
  data: {
    dishes: [
      { 
        name: '宫保鸡丁', price: 30, img: '/images/宫保鸡丁.png',
        protein: 25, calories: 420, fat: 18, carbs: 22 
      },
      { 
        name: '鱼香肉丝', price: 25, img: '/images/鱼香肉丝.png',
        protein: 23, calories: 390, fat: 15, carbs: 25 
      },
      { 
        name: '麻婆豆腐', price: 20, img: '/images/麻婆豆腐.png',
        protein: 19, calories: 350, fat: 12, carbs: 18 
      },
      { 
        name: '红烧肉', price: 35, img: '/images/红烧肉.png',
        protein: 28, calories: 500, fat: 30, carbs: 15 
      },
      { 
        name: '水煮鱼', price: 40, img: '/images/水煮鱼.png',
        protein: 35, calories: 460, fat: 20, carbs: 8 
      },
      { 
        name: '锅包肉', price: 30, img: '/images/锅包肉.png',
        protein: 22, calories: 430, fat: 25, carbs: 20 
      },
      { 
        name: '糖醋排骨', price: 28, img: '/images/糖醋排骨.png',
        protein: 26, calories: 450, fat: 18, carbs: 22 
      },
      { 
        name: '黄焖鸡', price: 32, img: '/images/黄焖鸡.png',
        protein: 32, calories: 420, fat: 16, carbs: 10 
      },
      { 
        name: '酸辣土豆丝', price: 15, img: '/images/酸辣土豆丝.png',
        protein: 3, calories: 120, fat: 2, carbs: 25 
      },
      { 
        name: '梅菜扣肉', price: 38, img: '/images/梅菜扣肉.png',
        protein: 24, calories: 480, fat: 28, carbs: 15 
      },
      { 
        name: '蒜泥白肉', price: 35, img: '/images/蒜泥白肉.png',
        protein: 27, calories: 470, fat: 22, carbs: 12 
      },
      { 
        name: '地三鲜', price: 20, img: '/images/地三鲜.png',
        protein: 20, calories: 150, fat: 7, carbs: 20 
      }
    ],
    cart: [],
    showCart: false,
    showOrderButtons: false,
    showConfirmation: false // 控制确认弹出层显示
  },

  // 添加到购物车
  addToCart: function (e) {
    const dishName = e.currentTarget.dataset.name;
    const dishPrice = e.currentTarget.dataset.price;
    const dishProtein = e.currentTarget.dataset.protein;
    const dishCalories=e.currentTarget.dataset.calories;
    const dishFat=e.currentTarget.dataset.fat;
    const dishCarbs=e.currentTarget.dataset.carbs;
    const dishImage=e.currentTarget.dataset.image;
    const cart = this.data.cart;
    const foundIndex = cart.findIndex(item => item.name === dishName);
  
    if (foundIndex !== -1) {
      cart[foundIndex].quantity += 1;
    } else {
      cart.push({ name: dishName, price: dishPrice, quantity: 1 ,protein:dishProtein
        ,calories:dishCalories,fat:dishFat,carbs:dishCarbs,image:dishImage});
      }
    
  
    this.setData({ cart });
    wx.showToast({ title: '已加入点餐车', icon: 'success' });
  },
  


  // 从购物车移除一份菜品
  removeFromCart: function (e) {
    const dishName = e.currentTarget.dataset.name;
    const cart = this.data.cart;
    const foundIndex = cart.findIndex(item => item.name === dishName);

    if (foundIndex !== -1) {
      if (cart[foundIndex].quantity > 1) {
        cart[foundIndex].quantity -= 1;
      } else {
        cart.splice(foundIndex, 1);
      }
    }

    this.setData({ cart }, () => {
      if (this.data.cart.length === 0) {
        this.setData({ showCart: false });
      }
    });

    wx.showToast({ title: '已移除一份', icon: 'none' });
  },

  // 切换购物车弹出层显示隐藏
  toggleCart: function () {
    if (this.data.cart.length === 0) {
      wx.showToast({ title: '购物车为空', icon: 'none' });
    } else {
      this.setData({ 
        showCart: !this.data.showCart,
        showOrderButtons: !this.data.showOrderButtons
      });
    }
  },

  // 显示确认弹出层
  
  onShow: function () {
    this.setData({
      showConfirmation: false, // 返回时关闭弹出层
      showCart: false, // 确保购物车关闭
      showOrderButtons: false // 确保订单按钮隐藏
    });
  },
  // 显示确认弹出层
  showConfirmation: function () {
    this.setData({ showConfirmation: true });
  },

  // 确认点单
  confirmOrder: function () {
    wx.showToast({ title: '订单已确认', icon: 'success' });
  
    // 将购物车内容存储到本地存储
    wx.setStorageSync('cart', this.data.cart); // 使用 wx.setStorageSync 存储购物车信息
  
    // 跳转到订单确认页面
    wx.navigateTo({
      url: '/pages/orderConfirmation/orderConfirmation' // 将路径替换为你的订单确认页面路径
    });
  
    // 清空购物车
    this.setData({ cart: [] });
    this.toggleCart(); // 关闭购物车
  },
  

  // 取消点单
 // 取消点单
 cancelOrder: function () {
  this.setData({ showConfirmation: false }); // 关闭确认弹出层
},
  // 页面加载时初始化


  

  goToRecommendation: function () {
    // 检查登录状态
    const userInfo = wx.getStorageSync('userInfo'); // 获取缓存中的用户信息
    if (userInfo) {
      this.setData({
        isLoggedIn: true,
        userInfo,
      });
      wx.navigateTo({
        url: '/pages/recommendation/recommendation' // 请确保这个路径是正确的
      });
    
    } else {
      wx.showToast({
        title: '请先登录',
        icon: 'none',                    
      });
    }
  },
  // 增加数量
  increaseQuantity(event) {
    const name = event.currentTarget.dataset.name;
    const cart = this.data.cart.map((item) => {
      if (item.name === name) {
        item.quantity += 1;
      }
      return item;
    });
    this.setData({ cart });
  },

 // 减少数量
decreaseQuantity(event) {
  const name = event.currentTarget.dataset.name; // 获取当前菜品的名称
  const cart = this.data.cart; // 获取购物车数据
  const index = cart.findIndex(item => item.name === name); // 查找该菜品在购物车中的索引

  if (index !== -1) {
    if (cart[index].quantity > 1) {
      cart[index].quantity -= 1; // 如果数量大于1，则减少1
    } else {
      cart.splice(index, 1); // 如果数量等于1，则从购物车中移除该菜品
    }
  }

  this.setData({ cart }, () => {
    if (cart.length === 0) {
      this.setData({ showCart: false }); // 如果购物车为空，关闭购物车弹出层
    }
  });

  wx.showToast({ title: '已减少一份', icon: 'none' });
},


})