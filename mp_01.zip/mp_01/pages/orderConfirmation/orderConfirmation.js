Page({
  data: {
    cart: [],  // 订单中的菜品
    totalPrice: 0, // 总价
    totalCalories: 0, // 总卡路里
    totalProtein: 0, // 总蛋白质
    totalFat: 0, // 总脂肪
    totalCarbs: 0 // 总碳水化合物
  },

  onLoad: function () {
    // 从本地存储获取购物车数据
    const cart = wx.getStorageSync('cart') || [];
    let totalPrice = 0;
    let totalCalories = 0;
    let totalProtein = 0;
    let totalFat = 0;
    let totalCarbs = 0;

    // 计算总价格、总卡路里和其他营养信息
    cart.forEach(item => {
      totalPrice += item.price * item.quantity;
      totalCalories += item.calories * item.quantity;
      totalProtein += item.protein * item.quantity;
      totalFat += item.fat * item.quantity;
      totalCarbs += item.carbs * item.quantity;
    });

    // 更新数据到页面上显示
    this.setData({
      cart: cart,
      totalPrice: totalPrice.toFixed(2), // 总价保留两位小数
      totalCalories: totalCalories, 
      totalProtein: totalProtein,
      totalFat: totalFat,
      totalCarbs: totalCarbs
    });
  },

  // 确认订单处理逻辑
  confirmOrder: function () {
    const userInfo = wx.getStorageSync('userInfo'); // 获取缓存中的用户信息
    if (userInfo) {
      this.setData({
        isLoggedIn: true,
        userInfo,
      });
      wx.showToast({
        title: '订单已确认',
        icon: 'success'
      });
      const cart = wx.getStorageSync('cart') || [];
  
      wx.navigateTo({
        url: '/pages/orderSuccess/orderSuccess',
        success: (res) => {
          // 使用事件通道传递数据到订单成功页面
          res.eventChannel.emit('passCartData', { cart });
        }
      });
    
    } else {
      wx.showToast({
        title: '请先登录',
        icon: 'none', 
      });
      wx.navigateTo({
        url: '/pages/login/login?redirect=/pages/orderConfirmation/orderConfirmation', // redirect为订单确认页面路径
      });
      
    }
   
  },

  // 返回首页
  goBack: function () {
    wx.redirectTo({
      url: '/pages/dishes/dishes',
    })
  }
});
