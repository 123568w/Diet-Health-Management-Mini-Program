Page({
  data: {
    account: '',
    password: '',
    phone: '',
    name: '',
    gender: 'male',
    height: '180',
    selectedGender: '',
    weight: '100',
    bmi: 0,
    bmiCategory: '',
    bmiSuggestion: '',
    menuList: [],
    bmiHistory: [22.5, 23.0, 23.5, 24, 25, 50, 40, 60,40],
    isLoggedIn: false, // 登录状态
    userInfo: {},      // 用户信息
  },

  // 页面加载时初始化
  onLoad: function () {
    this.checkLoginStatus(); // 检查登录状态
    this.renderBMITrend();
  },

  // 检查登录状态
  checkLoginStatus: function () {
    const userInfo = wx.getStorageSync('userInfo'); // 获取缓存中的用户信息
    if (userInfo) {
      this.setData({
        isLoggedIn: true,
        userInfo,
      });
      this.calculateBMI(); // 登录成功后计算BMI并更新数据
      this.setRecommendation();
    } else {
      wx.showToast({
        title: '请先登录',
        icon: 'none',
      });
      wx.redirectTo({
        url: '/pages/login/login', // 跳转到登录页面
      });
    }
  },

  // 计算BMI
  calculateBMI: function () {
    const { height, weight } = this.data.userInfo;
    if (height > 0 && weight > 0) {
      const bmi = (weight / ((height / 100) ** 2)).toFixed(1);
      let bmiCategory = '';
      let bmiSuggestion = '';

      // 根据BMI值分类
      if (bmi < 18.5) {
        bmiCategory = '体重过轻';
        bmiSuggestion = '建议适量增加饮食，补充营养。结合您的个人情况，我们为您准备了下面三个推荐菜单!';
      } else if (bmi >= 18.5 && bmi < 24.9) {
        bmiCategory = '正常范围';
        bmiSuggestion = '保持健康的饮食习惯！';
      } else if (bmi >= 25 && bmi < 29.9) {
        bmiCategory = '体重超重';
        bmiSuggestion = '建议控制热量摄入，增加锻炼。';
      } else {
        bmiCategory = '肥胖';
        bmiSuggestion = '建议合理饮食，控制体重，避免过量饮食。';
      }

      this.setData({
        bmi,
        bmiCategory,
        bmiSuggestion,
      });
    }
  },

  // 根据BMI设置推荐菜单
  setRecommendation: function () {
    const { bmi } = this.data;
    let menuList = [];

    if (bmi < 18.5) {
      // 菜单：体重过轻
      menuList = [
        {
          name: "营养能量餐",
          dish: [
            { dishName: "高蛋白鸡胸肉", calories: 250, img: "/images/高蛋白鸡胸肉.png" },
            { dishName: "牛油果沙拉", calories: 200, img: "/images/牛油沙拉果.png" },
          ],
        },
        {
          name: "增肌大餐",
          dish: [
            { dishName: "芝士焗土豆", calories: 300, img: "/images/芝士焗土豆.png" },
            { dishName: "鸡蛋三明治", calories: 250, img: "/images/鸡蛋三明治.png" },
          ],
        },
        {
          name: "活力满满套餐",
          dish: [
            { dishName: "牛肉炒面", calories: 350, img: "/images/牛肉炒面.png" },
            { dishName: "香蕉奶昔", calories: 180, img: "/images/香蕉奶昔.png" },
          ],
        }
      ];
    } else if (bmi >= 18.5 && bmi < 24.9) {
      // 菜单：正常体重
      menuList = [
        {
          name: "清爽健康餐",
          dish: [
            { dishName: "清蒸鱼", calories: 180, img: "/images/清蒸鱼.png" },
            { dishName: "蔬菜沙拉", calories: 100, img: "/images/蔬菜沙拉.png" },
          ],
        },
        {
          name: "日常能量餐",
          dish: [
            { dishName: "鸡肉沙拉", calories: 220, img: "/images/鸡肉沙拉.png" },
            { dishName: "水果拼盘", calories: 90, img: "/images/水果拼盘.png" },
          ],
        },
        {
          name: "清淡营养餐",
          dish: [
            { dishName: "煮鸡蛋", calories: 70, img: "/images/煮鸡蛋.png" },
            { dishName: "菠菜蘑菇汤", calories: 50, img: "/images/菠菜蘑菇汤.png" },
          ],
        }
      ];
    } else if (bmi >= 25 && bmi < 29.9) {
      // 菜单：体重超重
      menuList = [
        {
          name: "减脂套餐",
          dish: [
            { dishName: "清炒菠菜", calories: 80, img: "/images/清炒菠菜.png" },
            { dishName: "蒸鸡蛋", calories: 70, img: "/images/蒸鸡蛋.png" },
          ],
        },
        {
          name: "纤体轻食",
          dish: [
            { dishName: "烤鸡腿", calories: 150, img: "/images/烤鸡腿.png" },
            { dishName: "胡萝卜棒", calories: 50, img: "/images/胡萝卜棒.png" },
          ],
        },
        {
          name: "蔬果清爽餐",
          dish: [
            { dishName: "烤南瓜", calories: 60, img: "/images/烤南瓜.png" },
            { dishName: "黄瓜沙拉", calories: 40, img: "/images/黄瓜沙拉.png" },
          ],
        }
      ];
    } else {
      // 菜单：肥胖控制
      menuList = [
        {
          name: "低卡减重餐",
          dish: [
            { dishName: "蒸南瓜", calories: 60, img: "/images/蒸南瓜.png" },
            { dishName: "黄瓜拌木耳", calories: 50, img: "/images/黄瓜拌木耳.png" },
          ],
        },
        {
          name: "轻食控卡餐",
          dish: [
            { dishName: "烤豆腐", calories: 100, img: "/images/烤豆腐.png" },
            { dishName: "拌海带丝", calories: 50, img: "/images/拌海带丝.png" },
          ],
        },
        {
          name: "健康减脂餐",
          dish: [
            { dishName: "西兰花炒蛋", calories: 120, img: "/images/西兰花炒蛋.png" },
            { dishName: "生菜沙拉", calories: 40, img: "/images/生菜沙拉.png" },
          ],
        }
      ];
    }

    // 更新菜单数据
    this.setData({ menuList });
  },
  // 绘制BMI趋势图
  // 绘制BMI趋势图
 
});

