Page({
  data: {
    cart: []
  },

  onLoad: function (options) {
    const eventChannel = this.getOpenerEventChannel();

    // 接收来自确认订单页面的数据
    eventChannel.on('passCartData', (data) => {
      this.setData({ cart: data.cart });
    });
  },

  // 跳转到营养分析页面，并传递购物车数据
  goToNutritionAnalysis: function () {
    const cart = this.data.cart;

    wx.navigateTo({
      url: '/pages/analysis-nutrition/analysis-nutrition',
      success: (res) => {
        res.eventChannel.emit('passCartData', { cart });
      }
    });
  }
});
