Page({
  data: {
    account: '',
    password: '',
    captcha: '',
    inputCaptcha: '',
    userInfo: null, // 初始化为 null 而不是空字符串
    isLoading: false,
    isLoggedIn: false, // 登录状态
  },

  onLoad() {
    this.generateCaptcha();
    this.checkLoginStatus(); // 检查本地存储的用户信息
    // 获取 redirect 参数并记录
  if (options.redirect) {
    this.setData({ redirect: options.redirect });
  }
  },

  // 验证码生成
  generateCaptcha() {
    const captcha = Math.random().toString(36).substring(2, 6).toUpperCase();
    this.setData({ captcha });
  },

  // 检查登录状态
  checkLoginStatus() {
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo && userInfo.isLoggedIn) {
      this.setData({
        userInfo,
        isLoggedIn: true,
      });
    }
  },

  onAccountInput(e) {
    this.setData({ account: e.detail.value.trim() });
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  onCaptchaInput(e) {
    this.setData({ inputCaptcha: e.detail.value.toUpperCase() });
  },

  // 登录操作
  async onLogin() {
    const { account, password, inputCaptcha, captcha } = this.data;
  
    if (!account || !password) {
      wx.showToast({ title: '账号或密码不能为空', icon: 'none' });
      return;
    }
  
    if (inputCaptcha !== captcha) {
      wx.showToast({ title: '验证码错误', icon: 'none' });
      this.generateCaptcha();
      return;
    }
  
    this.setData({ isLoading: true });
  
    try {
      const res = await wx.cloud.callFunction({
        name: 'login',
        data: { account, password },
      });
  
      if (res.result && res.result.success) {
        const userInfo = {
          height: res.result.data.height,
          weight: res.result.data.weight,
          nickname: res.result.data.name,
          age: res.result.data.age,
          isLoggedIn: true,
          avatar: '/images/锅包肉.png',
        };
        wx.setStorageSync('userInfo', userInfo); // 存储用户信息
        this.setData({ userInfo, isLoggedIn: true });
  
        wx.showToast({ title: '登录成功', icon: 'success' });
  
        // 获取传递的 redirect 参数
        const redirect = this.options.redirect;
        if (redirect) {
          // 跳转到指定页面
          wx.redirectTo({ url: redirect });
        } else {
          // 默认跳转到个人中心
          wx.switchTab({ url: '/pages/profile/profile' });
        }
      } else {
        wx.showToast({ title: '账号或密码错误', icon: 'none' });
        this.generateCaptcha();
      }
    } catch (err) {
      console.error('登录失败:', err);
      wx.showToast({ title: '网络错误', icon: 'none' });
    } finally {
      this.setData({ isLoading: false });
    }
  },
  
  // 微信登录
  wxLogin() {
    wx.login({
      success: (res) => {
        if (res.code) {
          // 模拟微信登录成功后设置定值的用户信息
          const userInfo = {
            isLoggedIn: true,
            nickname: '默认用户', // 固定昵称
            avatar: '/images/default_avatar.png', // 固定头像
            height: 170, // 固定身高
            weight: 60,  // 固定体重
          };
  
          wx.setStorageSync('userInfo', userInfo); // 存储用户信息
          this.setData({ userInfo, isLoggedIn: true });
  
          wx.showToast({ title: '登录成功', icon: 'success' });
          wx.switchTab({ url: '/pages/profile/profile' });
        } else {
          wx.showToast({ title: '登录失败：' + res.errMsg, icon: 'none' });
        }
      },
      fail: () => {
        wx.showToast({ title: '微信登录失败', icon: 'none' });
      },
    });
  },
  
  // 跳转到注册页面
  onRegister() {
    wx.redirectTo({ url: '/pages/register/register' });
  },

  // 获取用户微信资料
  getUserProfile() {
    wx.getUserProfile({
      desc: '用于登录和获取用户信息',
      success: (res) => {
        const userInfo = {
          isLoggedIn: true,
          nickname: res.userInfo.nickName,
          avatar: res.userInfo.avatarUrl,
      
        };

        wx.setStorageSync('userInfo', userInfo); // 存储用户信息
        this.setData({ userInfo, isLoggedIn: true });

        wx.showToast({ title: '登录成功', icon: 'success' });
        wx.switchTab({ url: '/pages/profile/profile' });
      },
      fail: () => {
        wx.showToast({ title: '用户拒绝登录', icon: 'none' });
      },
    });
  },
});