Page({
  data: {
    account: '',
    password: '',
    phone: '',
    name: '',
    selectedGender: '',
    age:'',
    height: '',
    weight: ''
  },

  // 选择性别
  selectGender: function (e) {
    const gender = e.currentTarget.dataset.gender;
    this.setData({
      selectedGender: gender
    });
  },

  // 输入监听
  onNameInput: function (e) { this.setData({ name: e.detail.value }); },
  onAgeInput: function (e) { this.setData({ age: e.detail.value }); },
  onPhoneInput: function (e) { this.setData({ phone: e.detail.value }); },
  onHeightInput: function (e) { this.setData({ height: e.detail.value }); },
  onWeightInput: function (e) { this.setData({ weight: e.detail.value }); },
  onAccountInput: function (e) { this.setData({ account: e.detail.value }); },
  onPasswordInput: function (e) { this.setData({ password: e.detail.value }); },

  // 提交注册并存储信息到数据库
  async comeon() {
    const { account, password, phone, name, selectedGender,age, height, weight } = this.data;

    // 校验字段
    if (!name || !account || !password || !phone||!age) {
      wx.showToast({ title: '所有字段均为必填项', icon: 'none' });
      return;
    }
    if (password.length < 6) {
      wx.showToast({ title: '密码长度至少为6位', icon: 'none' });
      return;
    }
    const phoneRegex = /^[0-9]{11}$/;
    if (!phoneRegex.test(phone)) {
      wx.showToast({ title: '手机号必须为11位数字', icon: 'none' });
      return;
    }
    if ( age>100 || age <1) {
      wx.showToast({ title: '年龄范围必须在1到100岁之间', icon: 'none' });
      return;
    }
    if (height < 100 || height > 250) {
      wx.showToast({ title: '身高范围必须在100-250cm之间', icon: 'none' });
      return;
    }
   
    if (weight < 30 || weight > 200) {
      wx.showToast({ title: '体重范围必须在30-200kg之间', icon: 'none' });
      return;
    }

    // 保存用户数据到云数据库
    wx.showLoading({ title: '注册中...' });  // 显示加载动画

    try {
      const db = wx.cloud.database();  // 获取数据库实例
      const res = await db.collection('users').add({
        data: {
          account,
          password,  // 在实际项目中，请对密码进行加密处理
          phone,
          name,
          gender: selectedGender,
          age,
          height,
          weight,
          createdAt: new Date()  // 记录注册时间
        }
      });

      console.log('注册成功:', res);
      wx.showToast({ title: '注册成功', icon: 'success' });
      wx.switchTab({
        url: '/pages/profile/profile',
      });
      

    } catch (error) {
      console.error('注册失败:', error);
      wx.showToast({ title: '注册失败，请重试', icon: 'none' });
    } finally {
      wx.hideLoading();  // 隐藏加载动画
    }
  }
});
