Page({
  data: {
    isLoggedIn: false, // 标记是否登录
    nickname: '未知',
    age: '未知',
    height: '未知',
    weight: '未知',
    avatar: '/images/default-avatar.png', // 默认头像路径
  },
  // 登录页面跳转
  goToLogin: function () {
    wx.navigateTo({
      url: '/pages/login/login',
    });
  },
  onLoad: function () {
    const userInfo = wx.getStorageSync('userInfo'); // 从本地存储获取用户信息
    if (userInfo && userInfo.isLoading) {
      this.setData({
        isLoggedIn: true,
        avatar: userInfo.avatar ,
        nickname: userInfo.nickname || '未知'
      });
    } else {
      this.setData({ isLoggedIn: false });
    }
  },
  // 每次页面显示时检查登录状态
  onShow: function () {
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        isLoggedIn: true,
        avatar: userInfo.avatar,
        nickname: userInfo.nickname,
        age: userInfo.age,
        height: userInfo.height,
        weight: userInfo.weight,
      });
    } else {
      this.setData({ isLoggedIn: false });
    }
  },

  // 退出登录
  onLogout: function () {
    wx.removeStorageSync('userInfo'); // 清除缓存
    wx.reLaunch({
      url: '/pages/index/index', // 返回首页
    });
  },

  // 修改头像
  chooseAvatar: function () {
    if (!this.data.isLoggedIn) {
      wx.showToast({
        title: '请先登录后再修改头像',
        icon: 'none',
        duration: 2000,
      });
      return;
    }
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0];
        this.setData({ avatar: tempFilePath });

        // 更新并保存用户信息到缓存
        let userInfo = wx.getStorageSync('userInfo') || {};
        userInfo.avatar = tempFilePath;
        wx.setStorageSync('userInfo', userInfo);
      },
    });
  },

  // 跳转到目标设置页面
  goToGoalSetting: function () {
    if (!this.data.isLoggedIn) {
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 2000,
      });
      return;
    }
    wx.navigateTo({
      url: '/pages/goalSetting/goalSetting', // 跳转路径假设为目标设置页面
    });
  },
});
