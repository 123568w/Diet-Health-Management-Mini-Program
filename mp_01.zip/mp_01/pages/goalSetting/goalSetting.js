Page({
  data: {
    selectedGoal: '减肥', // 默认选择“减肥”
    targetWeight: 0
  },

  // 监听目标选择
  onGoalChange: function(e) {
    this.setData({
      selectedGoal: e.detail.value
    });
  },

  // 监听目标体重输入
  onWeightInput: function(e) {
    this.setData({
      targetWeight: e.detail.value
    });
  },

  // 提交健康目标
  submitGoal: function() {
    const { selectedGoal, targetWeight } = this.data;
    if (targetWeight > 0) {
      wx.showToast({
        title: '健康目标已保存！',
        icon: 'success',
        duration: 2000
      });

      // 假设存储在本地
      wx.setStorageSync('userGoal', {
        goal: selectedGoal,
        weight: targetWeight
      });

      // 跳转回个人中心或主页
      wx.navigateBack();
    } else {
      wx.showToast({
        title: '请输入目标体重',
        icon: 'none',
        duration: 2000
      });
    }
  }
});
